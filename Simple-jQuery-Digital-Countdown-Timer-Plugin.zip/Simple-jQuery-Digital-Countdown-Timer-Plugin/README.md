# jQuery Countdown Timer

Please see the [example page](http://code42.ru/misc/counter/).

